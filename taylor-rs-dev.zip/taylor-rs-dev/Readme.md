Rust Template Project
=====================

Rust template project for monorepo
