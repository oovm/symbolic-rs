## Tests

```bash
wee test
```
